# Customer Analysis – Project 02

## Overview

This project focuses on customer analysis using Python and explores customer behavior, spending patterns, membership tiers, discount usage, customer retention, and customer acquisition trends.

The analysis was performed on a cleaned customer dataset containing **60 customer records and 19 columns**.

## Objectives

The main objectives of this project were to:

* Create a short business overview using key KPIs.
* Recommend one city for the next marketing campaign and explain why.
* Select the 10 most valuable customers for a loyalty campaign.
* Identify customers who are at risk of leaving.
* Compare customers who used discounts with those who did not.
* Segment customers into meaningful groups.
* Check whether a small percentage of customers generates most of the revenue (Pareto Analysis).
* Design a simple dashboard for the CEO (3–5 charts).
* Provide three business recommendations supported by data.
* Describe the limitations of this dataset.

## Tools & Libraries

* Python
* Pandas
* NumPy
* Matplotlib
* Seaborn
* Jupyter Notebook

## Dataset

The final dataset contains:

* **60 customers**
* **19 columns**
* Customer information including demographics, location, signup date, membership tier, purchase behavior, spending, payment method, device, discount usage, returned items, satisfaction score, and analysis flags.

### Main Features

| Feature                     | Description                  |
| --------------------------- | ---------------------------- |
| `customer_id`               | Unique customer identifier   |
| `first_name`                | Customer first name          |
| `gender`                    | Customer gender              |
| `age`                       | Customer age                 |
| `city`                      | Customer city                |
| `province`                  | Customer province            |
| `signup_date`               | Customer signup date         |
| `membership_tier`           | Membership tier              |
| `purchase_count`            | Number of purchases          |
| `avg_order_value`           | Average order value          |
| `total_spending`            | Total customer spending      |
| `last_purchase_days`        | Days since the last purchase |
| `payment_method`            | Payment method               |
| `device`                    | Device used                  |
| `discount_used`             | Whether a discount was used  |
| `returned_items`            | Number of returned items     |
| `satisfaction_score`        | Customer satisfaction score  |
| `purchase_order_value_flag` | Data-quality flag            |
| `return_flag`               | Data-quality flag            |

The final dataset contains no missing values in the 19 columns.

## Analysis & Key Findings

### 1. Discount Usage Analysis

Customers who did not use discounts had higher average order value and average total spending than customers who used discounts:

* No discount: average order value **220.70**, average total spending **3,736.74**
* Discount used: average order value **203.29**, average total spending **2,882.17**

However, this analysis shows a relationship rather than causation. Therefore, the results do not establish that using discounts caused lower spending.

### 2. Membership Tier Analysis

Membership tiers showed different customer behaviors:

* **VIP:** highest average purchase frequency (**18.87**) and satisfaction score (**3.40**)
* **Silver:** highest average order value (**281.53**) and average total spending (**4,179.93**)
* **Gold:** largest customer group (**19 customers**) and second-highest average total spending (**3,955.43**)
* **Bronze:** **18 customers**, with average total spending of **3,166.66** and satisfaction score of **3.11**

Because Silver contains only 8 customers, its higher averages should be interpreted with caution.

### 3. At-Risk Customer Analysis

Customers with `last_purchase_days` above the 75th percentile (**273.75 days**) were classified as At-Risk.

The analysis identified:

* **15 At-Risk customers**
* **25%** of the customer base
* **38,757.75** in total spending
* **19.19%** of total customer spending

This indicates that targeted retention or win-back campaigns could help reduce potential revenue loss.

### 4. Pareto Analysis

Customers were ranked by `total_spending`, followed by calculation of cumulative spending and cumulative percentage.

The first **12 customers**, representing 20% of the customer base, accounted for approximately **51% of total spending**. The 80% spending threshold was reached at customer **28**, rather than around the first 12 customers.

Therefore, the dataset does **not** follow the traditional 80/20 Pareto pattern.

### 5. Customer Acquisition Trend

Customer sign-ups by year were:

| Year | New Customers |
| ---- | ------------: |
| 2021 |            17 |
| 2022 |            15 |
| 2023 |             8 |
| 2024 |            14 |
| 2025 |             6 |

The number of new customer sign-ups fluctuated over the period, with the highest number recorded in 2021 and the lowest in 2025.

## Dashboard

A simple CEO-oriented dashboard was created using four charts:

1. **Total Spending by Province**
2. **Total Spending by Membership Tier**
3. **Customer Sign-ups by Year**
4. **Total Spending by Discount Usage**

The dashboard was designed to provide a concise view of customer spending, membership performance, geographic differences, discount usage, and customer acquisition trends.

## Business Recommendations

Based on the analysis, three data-supported recommendations were developed:

### 1. Customer Retention

Launch targeted retention or win-back campaigns for the 15 At-Risk customers. This group represents **25% of the customer base** and accounts for **19.19% of total customer spending**.

### 2. Membership Strategy

Review and optimize membership strategies based on differences in customer behavior across tiers. VIP showed the highest purchase frequency and satisfaction, while Silver showed the highest average order value and average total spending. Gold had the largest customer group.

Because the Silver group contains only 8 customers, its higher averages should be interpreted cautiously.

### 3. Customer Acquisition

Investigate the decline in customer sign-ups and strengthen acquisition strategies. New customer sign-ups decreased from **17 in 2021 to 6 in 2025**, indicating a significant decline in recent customer acquisition.

## Dataset Limitations

The dataset has several limitations:

* The dataset contains only **60 customers**, limiting the generalizability of the findings.
* Each customer is represented by a single record, limiting analysis of individual behavior over time.
* Some segments have small sample sizes, particularly Silver with 8 customers.
* Important business variables such as customer income, website visits, acquisition channels, campaign costs, and profit margins are not available.
* The analysis identifies relationships and patterns but does not provide sufficient evidence to establish causation.
* The available signup data covers **2021–2025**, which limits long-term customer acquisition analysis.

## Conclusion

This project used Python to analyze customer behavior and generate business-oriented insights from spending, membership, retention, discount usage, and signup data. The analysis identified At-Risk customers, evaluated customer spending concentration, examined membership performance, analyzed acquisition trends, and translated the findings into actionable business recommendations.
