# Project 02 — Customer Behavior Analysis for the CEO

**Guiding question:** How can this analysis help the CEO make better business decisions?

This report answers the 6 official management questions from the project brief, using the
cleaned Project 01 dataset (60 customers, 17 columns) as the sole source of every number below.
Full code, charts, and outputs are in `customer_analytics.ipynb`.

---

## 1. Project Overview

Scenario: as a newly-hired Junior Data Analyst, the CEO needs a data-driven briefing —
demographics, the best city for the next campaign, who deserves loyalty rewards, who is about to
churn, whether discounts actually work, and a five-minute executive summary. Every figure here is
computed directly from the dataset; nothing is assumed or copied from any prior analysis.

## 2. Dataset

`source_cleaned_dataset.xlsx` — 60 customers × 17 columns: `customer_id`, `first_name`, `gender`,
`age`, `city`, `province`, `signup_date`, `membership_tier`, `purchase_count`,
`avg_order_value`, `total_spending`, `last_purchase_days`, `payment_method`, `device`,
`discount_used`, `returned_items`, `satisfaction_score`.

## 3. Data Quality

- **0 missing cells, 0 duplicate rows, 0 duplicate `customer_id`** — the dataset was already
  cleaned in Project 01.
- All numeric ranges are plausible: age 19–65, satisfaction 1–5, no negative spending or
  purchase counts.
- One customer (`1024`) has `purchase_count = 0` and `total_spending = 0` — a signed-up customer
  who never purchased. This is a legitimate value, not an error, and is kept in the analysis.

## 4. Gender Data Quality Issue — Name-Based Check

Before using `gender` in the profile below, it was cross-checked against `first_name` using the
conventional gender associated with each of the 12 first names actually present in the dataset
(e.g., Ali/Amir/Reza → male, Kimia/Maryam/Neda → female).

**Finding: 38 of 60 customers (63.3%) have a recorded `gender` that conflicts with the
gender conventionally associated with their name.** That is far too high to be random noise — it
points to a systemic problem in how `gender` was recorded or generated, not a handful of
one-off errors.

Important caveat: a first name is a cultural naming convention, not verified demographic ground
truth — this check is a **data-quality diagnostic**, not a correction of any individual's actual
gender. The original `gender` column was **never modified**; the check lives in two new columns
(`gender_inferred_from_name`, `gender_conflict`), saved in the `Gender QA` sheet of the results
workbook. Given the 63.3% conflict rate, `gender` should **not** be trusted for targeting or
reporting until its collection process is audited.

## 5. Question 1 — Who Are the Store's Main Customers?

*CEO's ask: before designing an ad campaign, show me age groups, gender, membership tier,
device, and payment method, and tell me what the dominant customer looks like.*

| Metric | Value |
|---|---|
| Number of customers | 60 |
| Mean / median age | 43.7 / 45.0 |
| Most common age group | 45–54 and 55–64 (15 and 16 customers — together just over half the base) |
| Most common membership tier | Gold |
| Most common device | Android |
| Most common payment method | Online Wallet |
| Most common gender (as recorded) | see note below |

**Gender is reported with an explicit caveat**, not stated flatly, because of the 63.3%
name/label conflict documented in Section 4 — picking either the recorded value or the
name-inferred value would overstate confidence in a field already shown to be unreliable.

> **Data-derived persona:** a customer in their mid-40s to mid-50s, most likely on **Gold**
> tier, using **Android**, paying via **Online Wallet**. Gender is intentionally left as an open
> question rather than guessed.

**Implication for the campaign:** this older, Android-using, wallet-paying profile is the safe
default for messaging and channel choice — but Section 7 (loyalty) shows the *most valuable*
customers aren't always the *most numerous* group, so a secondary high-value message may be
worth designing separately.

*Charts: `charts/q1_age_groups.png`, `q1_membership_tier.png`, `q1_device.png`,
`q1_payment_method.png`.*

## 6. Question 2 — Which City Should Get the Next Ad Campaign?

*CEO's ask: the ad budget is limited — which city has both a large customer base and strong
financial value, not just the highest total sales?*

| City | Province | Customers | Total Revenue | Avg. Spend/Customer | Avg. Satisfaction | Revenue Share |
|---|---|---|---|---|---|---|
| **Mashhad** | Khorasan | **11** | **$43,198** | $3,927 | 2.91 | **21.4%** |
| Tabriz | East Azerbaijan | 12 | $36,192 | $3,016 | 3.00 | 17.9% |
| Karaj | Alborz | 7 | $26,190 | $3,741 | 2.86 | 13.0% |
| Ahvaz | Khuzestan | 8 | $23,385 | $2,923 | 3.50 | 11.6% |
| Isfahan | Isfahan | 5 | $21,975 | $4,395 | 4.40 | 10.9% |
| Shiraz | Fars | 6 | $20,716 | $3,453 | 2.00 | 10.3% |
| Rasht | Gilan | 5 | $15,169 | $3,034 | 2.60 | 7.5% |
| Tehran | Tehran | 6 | $15,161 | $2,527 | 2.67 | 7.5% |

*(Cities with fewer than 3 customers are excluded to avoid unstable averages — none were dropped
here, all 8 cities in this dataset qualify.)*

**Recommendation: Mashhad.** It leads on every metric that matters for a broad campaign — the
most customers (11), the highest total revenue (21.4% of company-wide revenue), and a strong
average spend per customer ($3,927) — while satisfaction (2.91) sits right at the company
average, so there's no red flag about advertising into an unhappy base. Tabriz is a close second
on revenue but spreads it across more customers, each spending less — a lower-quality base per
head.

**Secondary pilot city: Isfahan.** Highest average spend per customer ($4,395) *and* the highest
satisfaction of any city (4.40) — but with only 5 customers it's too small and unproven to lead a
full campaign. Recommended as a smaller, high-touch pilot to test whether this quality holds as
the customer base there grows.

**Risk flag:** Shiraz has the *lowest* satisfaction of any qualifying city (2.00) despite
reasonable revenue — a poor target for a campaign even though the raw numbers look decent, since
it risks amplifying reach into an already-unhappy base. This is exactly why revenue, customer
count, and satisfaction were weighed together rather than picking by revenue alone.

*Charts: `charts/q2_top_cities.png`, `q2_city_scatter.png`.*

## 7. Question 3 — Which Customers Deserve Priority in the Loyalty Program?

*CEO's ask: we can only pick 10. I want high value, frequent purchasing, AND recent activity —
membership tier alone isn't good enough.*

**Method:** each customer was scored on a weighted, normalized (0–1) loyalty score:
`0.35 × Monetary + 0.30 × Frequency + 0.20 × Recency + 0.15 × Satisfaction`. Weights reflect
standard retention priorities — money and purchase frequency matter most, recency next (easier
to re-engage a recently-active customer), satisfaction as a softer tie-breaker. This is an
explicit analytical assumption, stated here rather than hidden in the code.

| Rank | Customer | Tier | Purchases | Total Spending | Days Since Purchase | Satisfaction | Loyalty Score |
|---|---|---|---|---|---|---|---|
| 1 | Maryam (#1057) | Bronze | 31 | $13,533 | 82 | 4 | 0.865 |
| 2 | Mina (#1044) | Gold | 33 | $14,354 | 165 | 2 | 0.781 |
| 3 | Ali (#1059) | Gold | 31 | $8,899 | 224 | 5 | 0.711 |
| 4 | Kimia (#1009) | Silver | 34 | $11,615 | 232 | 2 | 0.686 |
| 5 | Sina (#1004) | Gold | 23 | $6,121 | 40 | 4 | 0.638 |
| 6 | Arash (#1012) | Gold | 27 | $11,732 | 224 | 2 | 0.633 |
| 7 | Neda (#1033) | VIP | 24 | $5,521 | 112 | 5 | 0.630 |
| 8 | Reza (#1014) | VIP | 31 | $3,354 | 97 | 4 | 0.608 |
| 9 | Ali (#1023) | Bronze | 31 | $3,851 | 170 | 4 | 0.580 |
| 10 | Parsa (#1017) | VIP | 30 | $3,239 | 135 | 4 | 0.576 |

**Finding:** these 10 customers (17% of the base) generate **40.7% of total revenue** — a
compact, high-leverage loyalty list. Notably, the **#1-ranked customer is Bronze tier**, not
VIP, and 2 more Bronze customers make the top 10, while not every VIP customer appears at all.
This is an early sign — confirmed more fully in the discussion below — that `membership_tier`
does not reliably track actual customer value, so it should not be the sole basis for loyalty
invitations.

*Chart: `charts/q3_loyalty_scatter.png`.*

## 8. Question 4 — Which Valuable Customers Are at Risk of Going Inactive?

*CEO's ask: find customers who used to be valuable but haven't purchased in a long time — before
we lose them completely.*

**Definition (all three conditions required):** `total_spending` in the top quartile (≥
$4,213), `purchase_count` at or above the median (≥ 17), and `last_purchase_days` in the worst
quartile (≥ 274 days). Requiring all three avoids flagging casual low-spenders who simply
haven't purchased recently (not a real loss) and avoids flagging still-active big spenders — it
isolates customers who were **genuinely valuable and engaged, and have now gone quiet**.

| Customer | City | Days Since Purchase | Satisfaction | Total Spending | Tier |
|---|---|---|---|---|---|
| Arash (#1010) | Karaj | 276 | 1 | $7,241 | Silver |
| Arash (#1035) | Tabriz | 365 | 3 | $5,918 | Bronze |
| Sina (#1053) | Tehran | 320 | 1 | $5,806 | Gold |

**Result: 3 customers (5.0% of the base), representing ~$18,965 of historical revenue** — a
small, sharply-targeted win-back list. Recommended action differs by customer: Arash (#1010) and
Sina (#1053) both report satisfaction = 1 — these are unhappy, high-value customers who churned,
and deserve immediate personal outreach (account-manager call, tailored offer). Arash (#1035)
reports satisfaction = 3, suggesting he may simply be between purchase cycles rather than
actively dissatisfied — a lighter-touch re-engagement email is more appropriate there.

**Limitation:** the dataset only records *days since last purchase*, not full order history, so
this flags disengagement risk — it does not prove churn has already happened.

*Chart: `charts/q4_at_risk_scatter.png`.*

## 9. Question 5 — Discount, Device, and Payment Method vs. Customer Behavior

*CEO's ask: managers disagree on whether discounts help or hurt (via returns). Also compare
device and payment method — descriptively, without claiming causation.*

### Discount users vs. non-users

| Group | Customers | Avg. Spending | Avg. Purchases | Avg. Order Value | Avg. Returns | Avg. Satisfaction |
|---|---|---|---|---|---|---|
| No discount | 34 | $3,737 | 17.3 | $220.70 | 3.97 | 2.76 |
| Used discount | 26 | $2,882 | 17.5 | $203.29 | 3.58 | **3.27** |

### Statistical testing (Welch's t-test)

| Metric | t | p-value | Result |
|---|---|---|---|
| Total spending | -1.053 | 0.297 | No statistically significant difference detected in this sample |
| Satisfaction | 1.348 | 0.184 | No statistically significant difference detected in this sample |
| Purchase count | 0.077 | 0.939 | No statistically significant difference detected in this sample |

None of the three differences reach significance at n=60. Discount users do show directionally
higher satisfaction and fewer returns, but **this is observational data and does not establish
causality** — discount usage wasn't randomly assigned, so this could simply reflect which type of
customer chooses to use discounts, not an effect of the discount itself.

### Device

| Device | Customers | Avg. Spending |
|---|---|---|
| Web | 20 | $2,898 |
| Android | 22 | $3,459 |
| iPhone | 18 | **$3,774** |

### Payment method

| Method | Customers | Avg. Spending |
|---|---|---|
| Online Wallet | 23 | $3,104 |
| Cash | 19 | $3,151 |
| Card | 18 | **$3,929** |

All device and payment groups have a reasonable sample size (18–23 customers). iPhone users and
Card payers spend somewhat more on average — a descriptive pattern, not proof of cause and
effect; it may simply reflect that already higher-spending customers prefer these options.

*Charts: `charts/q5_discount_spending.png`, `q5_discount_returns.png`, `q5_device_spending.png`,
`q5_payment_spending.png`.*

## 10. Question 6 — CEO Five-Minute Report

### 6 KPIs

| KPI | Value |
|---|---|
| Total customers | 60 |
| Total revenue | $201,986 |
| Avg. customer value | $3,366 |
| Avg. satisfaction (1–5) | 2.98 |
| Discount usage rate | 43.3% |
| Valuable customers at risk | 3 ($18,965 revenue) |

### 3 charts
Top 10 cities by revenue · customer risk map (recency vs. spending) · discount vs. spending &
returns comparison — see `charts/q6_ceo_dashboard.png` plus the reproduced charts inside the
notebook.

### 3 Recommendations (KPI → Action → Evidence)

**1. Marketing**
- **KPI:** revenue and customer count by city
- **Action:** launch the next campaign in **Mashhad**; run a smaller, high-touch pilot in
  **Isfahan** to test whether its high per-customer value scales
- **Evidence:** Mashhad — 11 customers, 21.4% of total revenue, satisfaction in line with the
  company average. Isfahan — highest avg. spend/customer ($4,395) and satisfaction (4.40), but
  only 5 customers

**2. Retention**
- **KPI:** number and revenue of valuable at-risk customers
- **Action:** personal outreach and a tailored offer for the 3 valuable at-risk customers this
  month, prioritizing the two with satisfaction = 1
- **Evidence:** 3 customers (5% of the base) are both high-value and inactive, representing
  ~$18,965 of historical revenue

**3. Data / Experimentation**
- **KPI:** avg. spending by membership tier; discount test p-values
- **Action:** freeze `membership_tier`-based value decisions (loyalty invites, VIP perks) until
  the tier-assignment logic is audited; run a proper randomized A/B test before scaling
  discounting
- **Evidence:** average spending is not monotonic across tiers (Silver customers out-spend both
  Gold and VIP — see table below); none of the discount effects are statistically significant at
  n=60 (all p > 0.18)

| Tier | Avg. Spending |
|---|---|
| Bronze | $3,167 |
| **Silver** | **$4,180** |
| Gold | $3,955 |
| VIP | $2,426 |

VIP has the *lowest* average spending of all four tiers — a clear data-quality / business-rule
red flag that should be resolved before `membership_tier` is used for targeting.

## 11. Limitations

- Each row is a per-customer summary, not a per-order transaction log — trends and seasonality
  cannot be seen.
- "At risk" (Section 8) is an analytical rule, not confirmed, observed churn.
- The discount/device/payment comparisons (Section 9) are observational; none establish
  causation.
- `returned_items` records only the count of returned items, not total items purchased, so a
  true return *rate* cannot be computed.
- Small sub-groups (e.g., some cities) mean their averages should be read with caution.
- `gender` has a 63.3% conflict rate against name-based inference (Section 4) and should not be
  trusted for targeting until audited.
- `membership_tier` does not track spending reliably (Section 10) and should be audited before
  further use.
- Sample size (n=60) limits the statistical power of every test in this project.

## File Structure

```
project02_v2/
├── customer_analytics.ipynb        # full executed notebook — all 6 questions, all charts
├── README.md                       # this file — full written answers to all 6 questions
├── customer_analytics_results.xlsx # 9 sheets: KPIs, City Analysis, Top 10 Loyalty, At Risk,
│                                    #   Discount, Discount Tests, Device, Payment, Gender QA
├── source_cleaned_dataset.xlsx     # Project 01 cleaned input, unmodified
└── charts/                         # 13 charts, one set per question, exactly as requested
```
