# ===========================================================
# E-Commerce Customer Analytics & Executive Dashboard
# StudyBuild Project 02: Advanced Customer Behavior Analysis
# Author: Reyhaneh Akhond
# ===========================================================

import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

# Strict target directory setting
target_dir = r"C:\Users\kh computer\Desktop\Reyhan\Study & Build"

# Explicit File Paths
input_excel = os.path.join(target_dir, "cleaned_dataset_ReyhanehAkhond.xlsx")
excel_output = os.path.join(target_dir, "customer_analytics_results.xlsx")
dashboard_output = os.path.join(target_dir, "customer_analytics_dashboard.png")

# 1. Data Ingestion & Preprocessing
df = pd.read_excel(input_excel)

df["signup_date"] = pd.to_datetime(df["signup_date"], errors="coerce")

numeric_cols = [
    "age", "purchase_count", "avg_order_value", "total_spending",
    "last_purchase_days", "returned_items", "satisfaction_score"
]
for col in numeric_cols:
    df[col] = pd.to_numeric(df[col], errors="coerce")

text_cols = [
    "first_name", "gender", "city", "province", "membership_tier",
    "payment_method", "device", "discount_used"
]
for col in text_cols:
    df[col] = df[col].astype("string").str.strip()

print("[+] Dataset successfully loaded and standardized.")

# 2. Strategic Aggregations & Scoring Models
# KPI Summary
kpi_data = pd.DataFrame({
    "Metric": [
        "Total Unique Customers", "Total Gross Revenue ($)", 
        "Average Customer Lifetime Value ($)", "Average Orders per Customer", 
        "Average Satisfaction Score (1-5)", "Total Returned Units"
    ],
    "Value": [
        df["customer_id"].nunique(),
        round(df["total_spending"].sum(), 2),
        round(df["total_spending"].mean(), 2),
        round(df["purchase_count"].mean(), 2),
        round(df["satisfaction_score"].mean(), 2),
        df["returned_items"].sum()
    ]
})

# Regional Breakdown
geo_df = df.dropna(subset=["province", "city", "customer_id", "total_spending", "satisfaction_score"]).copy()
city_metrics = (
    geo_df.groupby(["province", "city"], as_index=False)
    .agg(
        customer_count=("customer_id", "nunique"),
        total_revenue=("total_spending", "sum"),
        avg_customer_spending=("total_spending", "mean"),
        avg_purchase_count=("purchase_count", "mean"),
        avg_order_value=("avg_order_value", "mean"),
        avg_satisfaction=("satisfaction_score", "mean")
    )
    .sort_values("total_revenue", ascending=False)
    .round(2)
)

# Composite Loyalty Score Engine
loyalty_df = df.copy()
for col in ["purchase_count", "total_spending", "satisfaction_score"]:
    min_val, max_val = loyalty_df[col].min(), loyalty_df[col].max()
    loyalty_df[f"{col}_score"] = (loyalty_df[col] - min_val) / (max_val - min_val)

rec_min, rec_max = loyalty_df["last_purchase_days"].min(), loyalty_df["last_purchase_days"].max()
loyalty_df["recency_score"] = 1.0 - ((loyalty_df["last_purchase_days"] - rec_min) / (rec_max - rec_min))

loyalty_df["loyalty_score"] = (
    0.35 * loyalty_df["total_spending_score"]
    + 0.30 * loyalty_df["purchase_count_score"]
    + 0.20 * loyalty_df["recency_score"]
    + 0.15 * loyalty_df["satisfaction_score_score"]
)
top_10_loyal = loyalty_df.nlargest(10, "loyalty_score")[[
    "customer_id", "first_name", "membership_tier", "purchase_count",
    "total_spending", "last_purchase_days", "satisfaction_score", "loyalty_score"
]].round(2)

# Churn Risk Matrix
risk_df = df.copy()
spend_cutoff = risk_df["total_spending"].quantile(0.75)
order_cutoff = risk_df["purchase_count"].median()
inactive_cutoff = risk_df["last_purchase_days"].quantile(0.75)

risk_df["at_risk"] = (
    (risk_df["total_spending"] >= spend_cutoff)
    & (risk_df["purchase_count"] >= order_cutoff)
    & (risk_df["last_purchase_days"] >= inactive_cutoff)
)

at_risk_list = risk_df.loc[risk_df["at_risk"], [
    "customer_id", "first_name", "membership_tier", "purchase_count",
    "total_spending", "last_purchase_days", "satisfaction_score"
]].sort_values(["total_spending", "last_purchase_days"], ascending=[False, False]).round(2)

# Promo Impact Comparison
discount_summary = (
    df.groupby("discount_used", as_index=False)
    .agg(
        customer_count=("customer_id", "nunique"),
        avg_total_spending=("total_spending", "mean"),
        avg_purchase_count=("purchase_count", "mean"),
        avg_order_value=("avg_order_value", "mean"),
        avg_returned_items=("returned_items", "mean"),
        avg_satisfaction=("satisfaction_score", "mean")
    )
    .round(2)
)

# 3. Export Formatted Excel Workbook (100% Center-Aligned)
with pd.ExcelWriter(excel_output, engine="openpyxl") as writer:
    kpi_data.to_excel(writer, sheet_name="KPI", index=False)
    city_metrics.to_excel(writer, sheet_name="City Analysis", index=False)
    top_10_loyal.to_excel(writer, sheet_name="Top Loyal Customers", index=False)
    at_risk_list.to_excel(writer, sheet_name="At Risk Customers", index=False)
    discount_summary.to_excel(writer, sheet_name="Discount Analysis", index=False)

# OpenPyXL Custom Styling
wb = load_workbook(excel_output)
header_fill = PatternFill(start_color="1F4E78", end_color="1F4E78", fill_type="solid")
header_font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
data_font = Font(name="Calibri", size=10)
center_alignment = Alignment(horizontal="center", vertical="center")
thin_border = Border(
    left=Side(style='thin', color='D9D9D9'),
    right=Side(style='thin', color='D9D9D9'),
    top=Side(style='thin', color='D9D9D9'),
    bottom=Side(style='thin', color='D9D9D9')
)

for sheetname in wb.sheetnames:
    ws = wb[sheetname]
    ws.views.sheetView[0].showGridLines = True
    
    # Format Headers
    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = center_alignment
    
    # Format All Data Cells (Forced Center Alignment)
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.font = data_font
            cell.border = thin_border
            cell.alignment = center_alignment
                
    # Auto-fit Column Widths
    for col in ws.columns:
        max_len = max(len(str(cell.value or '')) for cell in col)
        col_letter = col[0].column_letter
        ws.column_dimensions[col_letter].width = max(max_len + 6, 16)

wb.save(excel_output)
print(f"[+] Formatted Excel workbook saved directly to:\n    {excel_output}")

# 4. Generate Dashboard
plt.style.use('dark_background')
bg_color = '#0B0F19'
card_bg = '#111827'
border_color = '#1F2937'
text_main = '#F9FAFB'
text_muted = '#9CA3AF'

fig = plt.figure(figsize=(15, 9), facecolor=bg_color)
gs = fig.add_gridspec(2, 3, hspace=0.35, wspace=0.25)

def style_ax(ax, title):
    ax.set_facecolor(card_bg)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.spines['left'].set_color(border_color)
    ax.spines['bottom'].set_color(border_color)
    ax.tick_params(colors=text_muted, labelsize=9)
    ax.set_title(title, color=text_main, fontsize=11, fontweight='bold', pad=12, loc='left')

# Panel 01: Regional Revenue Leaders
ax1 = fig.add_subplot(gs[0, 0:2])
style_ax(ax1, "01. Top Revenue Generating Cities ($)")
top_5_cities = city_metrics.nlargest(5, 'total_revenue').sort_values('total_revenue')
bars1 = ax1.barh(top_5_cities['city'], top_5_cities['total_revenue'], color='#3B82F6', height=0.5)
for bar in bars1:
    xval = bar.get_width()
    ax1.text(xval + 500, bar.get_y() + bar.get_height()/2.0, f"${xval:,.0f}", ha='left', va='center', color=text_main, fontsize=9, fontweight='bold')

# Panel 02: Promo Spending Metrics
ax2 = fig.add_subplot(gs[0, 2])
style_ax(ax2, "02. Avg Spending by Discount ($)")
bars2 = ax2.bar(discount_summary['discount_used'], discount_summary['avg_total_spending'], color=['#06B6D4', '#F43F5E'], width=0.4)
for bar in bars2:
    yval = bar.get_height()
    ax2.text(bar.get_x() + bar.get_width()/2.0, yval + 80, f"${yval:,.0f}", ha='center', va='bottom', color=text_main, fontsize=9, fontweight='bold')

# Panel 03: Loyalty Index Top Ranked
ax3 = fig.add_subplot(gs[1, 0:2])
style_ax(ax3, "03. Top 5 Loyalty Index Ranking")
top_5_loyal = top_10_loyal.head(5).sort_values('loyalty_score')
bars3 = ax3.barh(top_5_loyal['first_name'] + " (ID:" + top_5_loyal['customer_id'].astype(str) + ")", top_5_loyal['loyalty_score'], color='#10B981', height=0.5)
for bar in bars3:
    xval = bar.get_width()
    ax3.text(xval + 0.01, bar.get_y() + bar.get_height()/2.0, f"{xval:.2f}", ha='left', va='center', color=text_main, fontsize=9, fontweight='bold')

# Panel 04: Churn Risk Inactivity
ax4 = fig.add_subplot(gs[1, 2])
style_ax(ax4, "04. At-Risk VIP Inactivity (Days)")
bars4 = ax4.bar(at_risk_list['first_name'] + "\n(" + at_risk_list['customer_id'].astype(str) + ")", at_risk_list['last_purchase_days'], color='#EF4444', width=0.45)
for bar in bars4:
    yval = bar.get_height()
    ax4.text(bar.get_x() + bar.get_width()/2.0, yval + 5, f"{yval} days", ha='center', va='bottom', color=text_main, fontsize=9, fontweight='bold')

fig.suptitle("EXECUTIVE DATA DASHBOARD: CUSTOMER INTELLIGENCE", color=text_main, fontsize=16, fontweight='bold', x=0.08, y=0.98, ha='left')
plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.savefig(dashboard_output, dpi=300, bbox_inches='tight', facecolor=bg_color)
plt.close()

print(f"[+] Executive Dashboard image saved directly to:\n    {dashboard_output}")