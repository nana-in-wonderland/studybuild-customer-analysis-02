# Customer Behavior Analytics & Strategic Intelligence
**Author:** Reyhaneh Akhond  
**Domain:** Financial Management & E-Commerce Data Analytics  
**Repository:** StudyBuild / Project 02  

---

## Overview

This project provides an end-to-end analytical evaluation of customer purchase behavior, geographic revenue distribution, and promotional sensitivity for an e-commerce platform. By applying exploratory data analysis (EDA), RFM-inspired loyalty modeling, and churn risk classification, the output translates complex transactional logs into clear, high-impact business strategies for retention and campaign planning.

---

## Executive Visual Dashboard

![Executive Intelligence Dashboard](customer_analytics_dashboard.png)

---

## Core Analytical Insights

### 1. Customer Persona & Engagement Channels
* **Active User Base:** 60 validated unique customer profiles analyzed.
* **Core Demographics:** Average customer age is **43.7 years** (median: 45.0), with female shoppers making up the primary target segment.
* **Tier & Platform Preferences:** **Gold Tier** members show the highest engagement level. Purchases are predominantly driven via **Android** devices, with **Online Wallets** serving as the preferred payment method.

### 2. Geographic Revenue Breakdown
* **Top Performing Cities:**
  1. **Mashhad:** $43,198 Total Gross Revenue
  2. **Tabriz:** $36,192 Total Gross Revenue
  3. **Karaj:** $26,190 Total Gross Revenue
  4. **Ahvaz:** $23,385 Total Gross Revenue
  5. **Isfahan:** $21,975 Total Gross Revenue
* **Strategic Takeaway:** Regional marketing budgets should focus heavily on Mashhad and Tabriz, which together drive the largest share of overall platform revenue.

### 3. Priority Loyalty Ranking System
To identify key candidates for exclusive loyalty perks, a multi-factor scoring model was built using normalized metrics:

$$\text{Loyalty Score} = 0.35(\text{Spending}) + 0.30(\text{Frequency}) + 0.20(\text{Recency}) + 0.15(\text{Satisfaction})$$

**Top Priority Candidates:**
- **Maryam (ID: 1057)** — Loyalty Index: **0.87**
- **Mina (ID: 1044)** — Loyalty Index: **0.80**
- **Ali (ID: 1059)** — Loyalty Index: **0.71**
- **Kimia (ID: 1009)** — Loyalty Index: **0.71**
- **Arash (ID: 1012)** — Loyalty Index: **0.66**

### 4. High-Value At-Risk Churn Detection
Customers in the top 25th percentile for spending ($\ge 75$th percentile) and purchase volume ($\ge$ median) who have not placed an order in over **200+ days** were flagged for churn risk.

**Flagged VIP Customers At Risk:**
- **Arash (ID: 1035):** Inactive for **365 days** ($5,000 Spend)
- **Sina (ID: 1053):** Inactive for **320 days** ($4,800 Spend)
- **Arash (ID: 1010):** Inactive for **276 days** ($4,500 Spend)

### 5. Promotional Behavior & Margin Impact
* **Full-Price Buyers:** Average Spend = **$3,737** | Satisfaction Score = **3.53**
* **Discount Buyers:** Average Spend = **$2,882** | Satisfaction Score = **3.31**
* **Business Takeaway:** Broad promotional discounts attract price-sensitive shoppers without boosting long-term basket size or overall satisfaction.

---

## Executive KPI Summary

| Key Metric | Value |
| :---: | :---: |
| **Total Unique Customers** | 60 |
| **Total Gross Revenue** | $197,350.00 |
| **Average Customer Lifetime Value** | $3,289.17 |
| **Average Orders per Customer** | 12.4 |
| **Average Satisfaction Score** | 3.42 / 5.0 |
| **Total Returned Units** | 148 |

---

## Actionable Business Recommendations

1. **VIP Re-engagement Strategy:** Launch direct outreach campaigns (personalized concierge offers) to high-spending inactive VIPs (ID: 1035, ID: 1053) to reduce churn.
2. **Geographic Reallocation:** Allocate at least 50% of upcoming performance marketing spend toward Mashhad and Tabriz to capture high-intent demand.
3. **Margin Protection:** Replace blanket site-wide discounts with minimum-spend threshold promotions (e.g., "$50 off on orders over $400") to protect margins while driving average order value (AOV).